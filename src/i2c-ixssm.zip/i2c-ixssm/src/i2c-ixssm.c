/*
 * drivers/i2c/busses/i2c-ix_ssm.c
 *
 * Support for the
 * - I2C interface on IX power module
 * - MCU interrupt GPIO
 *
 * Copyright (c) 2019 Stefan Alth�fer (as@janztec.com)
 *
 * Based on original work by some driver in linux/driver/i2c.
 *
 * This program is free software; you can redistribute  it and/or modify it
 * under  the terms of  the GNU General  Public License as published by the
 * Free Software Foundation;  either version 2 of the  License, or (at your
 * option) any later version.
 *
 */

/*
 * NOTES:
 *
 * Although the driver now does more than just i2c, it is still named
 * i2c-ixssm for compatibility (existing init scripts and ixconfig).
 *
 * There is a mess of names. Remember, the name of the unit as described
 * in the hardware manual is SSM (sychronus serial module). 
 *    filename:        i2c-ixssm.c -> i2c-ixssm.ko
 *    loaded module:   i2c_ixssm  (dash replaced by underscore)
 *    i2c-bus name:    IX-SSM-I2C
 *    platform device: IX-SSM 
 *    gpiochip label:  IX-SSM-GPIO
 *    irq chip name:   IX-SSM
 *
 * To use the MCU interrupt GPIO, the following must be enabled
 * in the kernel:
 * - CONFIG_GPIOLIB
 * - CONFIG_GENERIC_IRQ_CHIP.
 *   I found no way to enable GENERIC_IRQ_CHIP directy for x86
 *   architechtures.  However it gets implicitly enabled when enabling
 *   a driver which needs it (e.g.  CONFIG_GPIO_ML_IOH)
 * 
 * When using the GPIO interrupt: One it has triggered, you need to
 * set egde to "none" and then againg to "falling" to get the
 * interrupt armed again.
 *
 * FIXME:
 *
 * Shadow variables not synchronized with use in interrupts.  This
 * might be critical for the int_shadow variable.
 *
 * Tested only for x86 (emPC-X), kernel 4.8.3, 4.19.67
 */


#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/ioport.h>
#include <linux/delay.h>
#include <linux/slab.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <asm/irq.h>
#include <asm/io.h>
#include <linux/i2c.h>
#include <linux/platform_device.h>

#if defined(CONFIG_GPIOLIB) && defined(CONFIG_GENERIC_IRQ_CHIP)
#define IXSSM_MCU_GPIO
#else
#undef IXSSM_MCU_GPIO
#warning "compile without MCU GPIO support"
#endif

#ifdef IXSSM_MCU_GPIO
#include <linux/gpio/driver.h>
#include <linux/syscalls.h>
#include <linux/seq_file.h>
#endif



#define SSM_I2C_DATA    0x00
#define SSM_I2C_CNTRL   0x04
#define SSM_I2C_INT     0x08
#define SSM_SPI_DATA    0x0C
#define SSM_SPI_CNTRL   0x10
#define SSM_SPI_INT     0x14
#define SSM_BITRATE     0x18
#define SSM_RESET       0x1c

/* I2C_DATA */
#define SSM_I2C_DATA_ACKI   (1<<0)  /* on reads */
#define SSM_I2C_DATA_BUSY   (1<<1)  /* on reads */
#define SSM_I2C_DATA_MINT   (1<<2)  /* on reads */
#define SSM_I2C_DATA_INT    (1<<3)  /* on reads */
#define SSM_I2C_DATA_IN(X)  (((X)>>8)&0xff)
#define SSM_I2C_DATA_OUT(X) (((X)&0xff)<<8)
#define SSM_I2C_DATA_S      (1<<2)  /* write only */
#define SSM_I2C_DATA_P      (1<<3)  /* write only */

/* I2C_CNTRL */
#define SSM_I2C_CNTRL_ACKO  (1<<0)  /* write only */
#define SSM_I2C_CNTRL_RW    (1<<1)  /* write only */
#define SSM_I2C_CNTRL_S     (1<<2)  /* write only */
#define SSM_I2C_CNTRL_P     (1<<3)  /* write only */

/* I2C_INT */
#define SSM_I2C_INT_IE      (1<<0)  /* write only */
#define SSM_I2C_INT_MIE     (1<<1)  /* write only */
#define SSM_I2C_INT_ACK     (1<<2)  /* write only */


#define DRIVER_VERSION "1.3"

static uint base;
static int irq;


#define DBG_LEVEL 0

#ifdef DBG
#undef DBG
#endif

#ifdef DBG2
#undef DBG2
#endif

#if DBG_LEVEL > 0
#  define DBG(f,x...)   printk(KERN_DEBUG "ix-ssm-i2c" f, ##x)
#else
#  define DBG(f,x...)   ((void)0)
#endif
#if DBG_LEVEL > 1
#  define DBG2(f,x...)  DBG(f, ##x)
#else
#  define DBG2(f,x...)  ((void)0)
#endif
#if DBG_LEVEL > 2
static void dump_iic_regs(const char* header, struct ix_ssm_private* dev)
{
	volatile void __iomem *iic = dev->vaddr;
}
#  define DUMP_REGS(h,dev)	dump_iic_regs((h),(dev))
#else
#  define DUMP_REGS(h,dev)	((void)0)
#endif

static void ix_ssm_exit_local(void);

struct ix_ssm_private {
	struct i2c_adapter	 adap;
	int			 idx;
	int			 irq;
	int			 busy_timeout;
	unsigned short		 cntrl_shadow;
	unsigned short		 int_shadow;
	unsigned short		 bitrate_shadow;
	volatile int		 int_enable;
	volatile void __iomem	 *vaddr;
	wait_queue_head_t	 wq;
	volatile int             intflg;
#ifdef IXSSM_MCU_GPIO
	struct gpio_chip         gpio;
	int                      ichip_irq_base;
#endif
};

static struct ix_ssm_private mydev[1];
static struct platform_device *ix_ssm_pdev;

/*
 * Initialize IIC interface.
 */
static void iic_dev_init(struct ix_ssm_private* dev)
{
	volatile void __iomem *iic = dev->vaddr;

	/* Perform reset */
	writew(0, iic+SSM_RESET);

	dev->int_shadow = 0;
	writew(dev->int_shadow, iic+SSM_I2C_INT);

	/* Set 400kHz bitrate */
	dev->bitrate_shadow = 1;
	writew(dev->bitrate_shadow, iic+SSM_BITRATE);

	dev->cntrl_shadow = 0;

	DUMP_REGS("iic_init", dev);
}

/* 
 * Reset IIC interface
 */
static void iic_dev_reset(struct ix_ssm_private* dev)
{
	/*volatile void __iomem *iic = dev->vaddr;*/

	/* FIXME: try to resolve stuck devices */
	
	/* Reinitialize interface */
	iic_dev_init(dev);
}


/*
 * IX-SSM interrupt handler. Handle both, the i2c and the mcu interrupt
 */
static irqreturn_t iic_handler(int irq, void *dev_id)
{
	struct ix_ssm_private* dev = (struct ix_ssm_private*)dev_id;
	volatile void __iomem *iic = dev->vaddr;
	unsigned short dreg;
	int ret = IRQ_NONE;

	if( dev->irq >= 0 ){
		dreg = readw(iic+SSM_I2C_DATA);
		if( dreg & SSM_I2C_DATA_INT ){
			/* Ack IRQ */
		        writew(dev->int_shadow+SSM_I2C_INT_ACK, iic+SSM_I2C_INT);
			
			dev->intflg = 1;
			wake_up(&dev->wq);
			ret = IRQ_HANDLED;
		}
#ifdef IXSSM_MCU_GPIO
		if( dreg & SSM_I2C_DATA_MINT ){
			if( dev->int_shadow & SSM_I2C_INT_MIE ){
				/* Clear int enable if the Int has been seen.
				   This way we implement falling edge */
				dev->int_shadow &= ~SSM_I2C_INT_MIE;
				writew(dev->int_shadow, iic+SSM_I2C_INT);
				DBG("%d: handle irq %d\n", dev->idx, dev->ichip_irq_base);
				generic_handle_irq(dev->ichip_irq_base);
				ret = IRQ_HANDLED;
			}
		}
#endif
	}

	return ret;
}


/*
 * Check for I2C unit to be idle. If not idle, then less than
 * zero is returned, else the value of the data register.
 */
static int iic_check_for_idle(struct ix_ssm_private* dev)
{
	volatile void __iomem *iic = dev->vaddr;
	unsigned short	dreg;
	
	dreg = readw(iic+SSM_I2C_DATA);
	if( (dreg & SSM_I2C_DATA_BUSY) ){
		return -1;
	} else {
		return dreg & 0xffff;
	}
}

/*
 * Wait for I2C unit to become idle. On timeout, return less than
 * zero, else the value of the data register.
 */
static int iic_wait_for_idle(struct ix_ssm_private* dev, int force_poll)
{
	volatile void __iomem *iic = dev->vaddr;
	unsigned short	dreg;
	int  timeout;
	int  ret;

	if( (dev->irq >= 0) && !force_poll ){
		ret = wait_event_timeout(
		        dev->wq, dev->intflg,
			dev->busy_timeout);
		
		if( (ret > 0) || (ret==0 && dev->intflg==1) ){
			dev->intflg = 0;
			dreg = readw(iic+SSM_I2C_DATA);
			return dreg & 0xffff;
		} else {
			/* Timeout or signal. */
			return -1;
		}
	} else {
		timeout = 1000;
		while(1){
			timeout--;
			dreg = readw(iic+SSM_I2C_DATA);
			if( (dreg & SSM_I2C_DATA_BUSY) ){
				if( timeout > 0 ){
					continue;
				} else {
					return -1;
				}
			} else {
				return dreg & 0xffff;
			}
		}
	}
}
	
/* build the addr byte to transmitt from address and flags */
static int make_address_byte(struct i2c_msg* pm)
{
	int    rw;

	if( unlikely(pm->flags&I2C_M_REV_DIR_ADDR) ){
		rw = (pm->flags&I2C_M_RD)?0:1;
	} else {
		rw = (pm->flags&I2C_M_RD)?1:0;
	}
	return (pm->addr<<1)+rw;
}


/*
 * Low level master transfer routine
 *
 * FIXME: Need to handle I2C_M_NOSTART and I2C_M_NO_RD_ACK
 *
 */
static int iic_xfer_bytes(struct ix_ssm_private* dev, struct i2c_msg* pm, 
			  int combined_xfer)
{
	volatile void __iomem *iic = dev->vaddr;
	int		      i, ret = 0;
	int		      dreg;
	int		      stopped = 0;

	DBG2("%d: xfer_bytes (addr=0x%.2x, flags=0x%x, len=%d)\n", dev->idx,
	     pm->addr, pm->flags, pm->len );

	if( iic_check_for_idle(dev) < 0 ){
		DBG("%d: Unit not idle (call iic_dev_reset)\n", dev->idx);
		iic_dev_reset(dev);
	}

	/* trigger start condition and transfer address byte */
	dev->cntrl_shadow &= ~SSM_I2C_CNTRL_RW;
	writew(dev->cntrl_shadow, iic+SSM_I2C_CNTRL);

	dreg = SSM_I2C_DATA_S + SSM_I2C_DATA_OUT(make_address_byte(pm));
	if( (pm->len == 0) && !combined_xfer ){
	    /* Shedule stop after address if not combined transfer */
	    dreg |= SSM_I2C_DATA_P;
	    stopped = 1;
	}
	DBG2("%d: write address %x, dr %x\n", dev->idx, dreg>>8, dreg & 0xff);
	writew(dreg, iic+SSM_I2C_DATA);

	/* wait for start complete and address byte to transfer */
	if( (dreg=iic_wait_for_idle(dev,0)) < 0 ){
		DBG("%d: Not idle after start/address\n", dev->idx);
		ret = -EFAULT;
	} else {
		if( (dreg & SSM_I2C_DATA_ACKI) & !(pm->flags & I2C_M_IGNORE_NAK) ){
			DBG2("%d: No acknowledge from peer (addr)\n", dev->idx);
			ret = -EREMOTEIO;
		}
	}

	/* transfer data (will do nothing if len=0) */
	if( pm->flags & I2C_M_RD ){
		/* Read */
		dev->cntrl_shadow |=  SSM_I2C_CNTRL_RW;
		if( pm->len > 1 ){
			dev->cntrl_shadow &= ~SSM_I2C_CNTRL_ACKO;
		} else {
			dev->cntrl_shadow |=  SSM_I2C_CNTRL_ACKO;
		}
		writew(dev->cntrl_shadow, iic+SSM_I2C_CNTRL);
		for(i=0; (i<pm->len) && (ret==0); i++){
			if( ((i+1) >= pm->len) & (i!=0) ){
				/* No ACK for last byte */
				dev->cntrl_shadow |=  SSM_I2C_CNTRL_ACKO;
				writew(dev->cntrl_shadow, iic+SSM_I2C_CNTRL);
			}

			dreg = 0;
			if( ((i+1)==pm->len) && !combined_xfer ){
			    /* Shedule stop after last byte if not combined transfer */
			    dreg |= SSM_I2C_DATA_P;
			    stopped = 1;
			}
			DBG2("%d: byte in, dr %x\n", dev->idx, dreg & 0xff);
			writew(dreg, iic+SSM_I2C_DATA); /* dummy write triggers read */

			/* wait for data transfer (and maybe stop) to finish */
			if( (dreg=iic_wait_for_idle(dev,0)) < 0 ){
				DBG("%d: Not idle after read\n", dev->idx);
				ret = -EFAULT;
			}

			pm->buf[i] = SSM_I2C_DATA_IN(dreg);
		}
	} else {
		/* Write */
		dev->cntrl_shadow &= ~SSM_I2C_CNTRL_RW;
		writew(dev->cntrl_shadow, iic+SSM_I2C_CNTRL);
		for(i=0; (i<pm->len) && (ret==0); i++){
			dreg = SSM_I2C_DATA_OUT(pm->buf[i]);
			if( ((i+1)==pm->len) && !combined_xfer ){
			    /* Shedule stop after last byte if not combined transfer */
			    dreg |= SSM_I2C_DATA_P;
			    stopped = 1;
			}
			DBG2("%d: byte out %x, dr %x\n", dev->idx, dreg>>8, dreg & 0xff);
			writew(dreg, iic+SSM_I2C_DATA);

		
			/* wait for data transfer (and maybe stop) to finish */
			if( (dreg=iic_wait_for_idle(dev,0)) < 0 ){
				DBG("%d: Not idle after write\n", dev->idx);
				ret = -EFAULT;
			}
			if( (dreg & SSM_I2C_DATA_ACKI) & !(pm->flags & I2C_M_IGNORE_NAK) ){
				DBG("%d: No acknowledge from peer (data)\n", dev->idx);
				ret = -EREMOTEIO;
			}
		}
	}

	if( ret && !stopped ){
		/* Force  a stop condition when there had been an error and
		   stop had not already been sheduled. */
		writew(dev->cntrl_shadow | SSM_I2C_CNTRL_P, iic+SSM_I2C_CNTRL);
	    
		if( (dreg=iic_wait_for_idle(dev,0)) < 0 ){
			DBG("%d: Not idle after stop\n", dev->idx);
			ret = -EFAULT;
		}
	}
	
	return ret > 0 ? 0 : ret;
}

/*
 * Generic master transfer entrypoint. 
 * Returns the number of processed messages or error (<0)
 */
static int iic_xfer(struct i2c_adapter *adap, struct i2c_msg *msgs, int num)
{
	struct ix_ssm_private* dev = (struct ix_ssm_private*)(i2c_get_adapdata(adap));
	int    i, ret = 0;
	
	DBG2("%d: iic_xfer, %d msg(s)\n", dev->idx, num);
	
	if (!num)
		return 0;
	
	/* Do real transfer */
	for (i = 0; i < num && !ret; ++i)
		ret = iic_xfer_bytes(dev, &msgs[i], i < num - 1);

	return ret < 0 ? ret : num;
}


static u32 iic_func(struct i2c_adapter *adap)
{
	return I2C_FUNC_I2C | I2C_FUNC_SMBUS_EMUL;
}

static const struct i2c_algorithm iic_algo = {
	.master_xfer	= iic_xfer,
	.functionality	= iic_func
};


#ifdef IXSSM_MCU_GPIO
/* GPIO: The ix-smm-i2c provides only one input. This is the MCU Interrupt
   output.  */

/* Interrupt chip just for the MCU Interrupt. We need this, to have a
   unuiqe interrupt number to be connected to the gpiolib */

static int ixssm_irq_type(struct irq_data *d, unsigned int type)
{
	switch (type) {
	case IRQ_TYPE_EDGE_RISING:
		return -EINVAL;
	case IRQ_TYPE_EDGE_FALLING:
		break;
	case IRQ_TYPE_EDGE_BOTH:
		return -EINVAL;
	case IRQ_TYPE_LEVEL_HIGH:
		return -EINVAL;
	case IRQ_TYPE_LEVEL_LOW:
		return -EINVAL;
	default:
		/* FIXME: default should really return 0 ? */
		break;
	}

	return 0;
}

static void ixssm_irq_unmask(struct irq_data *d)
{
	struct irq_chip_generic *gc = irq_data_get_irq_chip_data(d);
	struct ix_ssm_private *dev = gc->private;
	volatile void __iomem *iic = dev->vaddr;

	dev->int_shadow |= SSM_I2C_INT_MIE;
	writew(dev->int_shadow, iic+SSM_I2C_INT);
	DBG("%d: set irq_unmask %d\n", dev->idx, dev->int_shadow);
}

static void ixssm_irq_mask(struct irq_data *d)
{
	struct irq_chip_generic *gc = irq_data_get_irq_chip_data(d);
	struct ix_ssm_private *dev = gc->private;
	volatile void __iomem *iic = dev->vaddr;

	dev->int_shadow &= ~SSM_I2C_INT_MIE;
	writew(dev->int_shadow, iic+SSM_I2C_INT);
	DBG("%d: set irq_mask %d\n", dev->idx, dev->int_shadow);
}

static void ixssm_irq_ack(struct irq_data *d)
{
	//struct irq_chip_generic *gc = irq_data_get_irq_chip_data(d);
	//struct ix_ssm_private *dev = gc->private;

	DBG("%d: do irq_ack\n", dev->idx);
}


static void ixssm_gpio_alloc_generic_chip(struct ix_ssm_private *dev,
				unsigned int irq_start, unsigned int num)
{
	struct irq_chip_generic *gc;
	struct irq_chip_type *ct;

	gc = irq_alloc_generic_chip("IX-SSM", 1, irq_start, (void *)(dev->vaddr),
				    handle_simple_irq);
	gc->private = dev;
	ct = gc->chip_types;

	ct->chip.irq_ack = ixssm_irq_ack;
	ct->chip.irq_mask = ixssm_irq_mask;
	ct->chip.irq_unmask = ixssm_irq_unmask;
	ct->chip.irq_set_type = ixssm_irq_type;

	irq_setup_generic_chip(gc, IRQ_MSK(num), IRQ_GC_INIT_MASK_CACHE,
			       IRQ_NOREQUEST | IRQ_NOPROBE, 0);
}

static int ixssm_gpio_to_irq(struct gpio_chip *gpio, unsigned offset)
{
	struct ix_ssm_private *dev = dev_get_drvdata(gpio->parent);

	DBG("%d: gpio_to_irq %d -> %d\n", dev->idx, dev->ichip_irq_base,dev->ichip_irq_base+offset);

	if( offset > 0 )
		return -EINVAL;

	return dev->ichip_irq_base + offset;
}

static int ixssm_get_value(struct gpio_chip *gpio, unsigned offset)
{
	struct ix_ssm_private *dev = dev_get_drvdata(gpio->parent);
	volatile void __iomem *iic = dev->vaddr;
	unsigned short	dreg;

	if( offset > 0 )
		return -EINVAL;

	dreg = readw(iic+SSM_I2C_DATA);
	/* A one in the DATA register actually indicates the input signal
	   is low. */
	if( (dreg & SSM_I2C_DATA_MINT) ){
		DBG("%d: gpio_get_value %d: 0\n", dev->idx, offset);
		return 0;
	} else {
		DBG("%d: gpio_get_value %d: 1\n", dev->idx, offset);
		return 1;
	}
}

static int ixssm_get_dir(struct gpio_chip *gpio, unsigned int offset)
{
	if( offset > 0 )
		return -EINVAL;

	/* Return 0 if output, 1 of input */
	/* We are always of type input */
	return 1;
}
#endif

/*
 * Register single IIC interface and GPIO chip
 */
static int __init ix_ssm_init(void){
	struct ix_ssm_private* dev = &mydev[0];
	struct i2c_adapter* adap;
	volatile void __iomem *iic;
	int ret;
#ifdef IXSSM_MCU_GPIO
	struct gpio_chip *gpio;
	int irq_base;
#endif

	dev->idx = 0;

	ix_ssm_pdev = platform_device_alloc("IX-SSM", -1);
	if (!ix_ssm_pdev) {
		printk(KERN_CRIT "ix-ssm-i2c%d: unable to alloc platform device\n",
		       dev->idx);
		ret = -ENOMEM;
		//goto unreg_pnp;
		return -1;
	}

	ret = platform_device_add(ix_ssm_pdev);
	if (ret){
		printk(KERN_CRIT "ix-ssm-i2c%d: unable to add platform device\n",
		       dev->idx);
		//goto put_dev;
		return -1;

	}

	platform_set_drvdata(ix_ssm_pdev, dev);

	if (!request_mem_region((resource_size_t)((unsigned long)base), 0x40, "ix_ssm")) {
		ret = -EBUSY;
		goto fail1;
	}

	if (!(dev->vaddr = ioremap((resource_size_t)((unsigned long)base), 0x40))) {
		printk(KERN_CRIT "ix-ssm-iic%d: failed to ioremap device registers\n",
		       dev->idx);
		ret = -ENXIO;
		goto fail2;
	}
	DBG("%d: vaddr=%p\n", dev->idx, dev->vaddr);
	iic = dev->vaddr;

	printk(KERN_INFO "IX-SSM init @ %x (irq = %d)\n", base, irq);
	init_waitqueue_head(&dev->wq);
	dev->intflg = 0;

	/* Initialize IIC interface (to make sure IRQ is disabled) */
	iic_dev_init(dev);
	
	dev->irq = irq;
	if (dev->irq >= 0){
		/* Disable interrupts until we finish initialization,
		   assumes level-sensitive IRQ setup...
		*/
		//iic_interrupt_mode(dev, 0);
		if (request_irq(dev->irq, iic_handler,
				IRQF_SHARED, "IX-SSM", dev)){
			printk(KERN_ERR "ix-ssm-i2c%d: request_irq %d failed\n", 
			       dev->idx, dev->irq);
			/* Fallback to the polling mode */	
			dev->irq = -1;
		} else {
		    /* enable the interrupt */
		    dev->int_shadow |= SSM_I2C_INT_IE;
		    writew(dev->int_shadow, iic+SSM_I2C_INT);
		}
	}
	
	if (dev->irq < 0)
		printk(KERN_WARNING "ix-ssm-i2c%d: using polling mode\n", 
		       dev->idx);
		
	dev->busy_timeout = msecs_to_jiffies(13) + 1; /* 13 ms */
	
	/* Register it with i2c layer */
	adap = &dev->adap;
	strcpy(adap->name, "IX-SSM-I2C");
	i2c_set_adapdata(adap, dev);
	//adap->id = 0x9999;
	adap->class = I2C_CLASS_HWMON;
	adap->algo = &iic_algo;
	adap->timeout = 1;
	adap->retries = 1;
	adap->dev.parent = &ix_ssm_pdev->dev;

	if ((ret = i2c_add_adapter(adap)) != 0){
		printk(KERN_CRIT "ix-ssm-i2c%d: failed to register i2c adapter\n",
		       dev->idx);
		goto fail;
	}

#ifdef IXSSM_MCU_GPIO
	/* Initialize the GPIO data structures */
	gpio = &dev->gpio;
	gpio->parent = &ix_ssm_pdev->dev;
	gpio->owner = THIS_MODULE;
	gpio->label = "IX-SSM-GPIO";
	gpio->get = ixssm_get_value;
	gpio->get_direction = ixssm_get_dir;
	gpio->to_irq = ixssm_gpio_to_irq;
	gpio->base = -1;  /* request dynamic allocation */
	gpio->ngpio = 1;
	gpio->can_sleep = false;
	
	ret = devm_gpiochip_add_data(&ix_ssm_pdev->dev, gpio, NULL);
	if (ret) {
		printk(KERN_CRIT "ix-ssm-i2c%d: unable to add GPIO chip\n",
		       dev->idx);
		return ret;
	}

	irq_base = irq_alloc_descs(-1, 0, 1, NUMA_NO_NODE);
	DBG("%d: irq_alloc_descs = %d\n", dev->idx, irq_base);
	if (irq_base < 0) {
		printk(KERN_CRIT "ix-ssm-i2c%d: Failed to get IRQ base num\n",
		       dev->idx);
		dev->ichip_irq_base = -1;
		goto fail;
	}
	dev->ichip_irq_base = irq_base;

	ixssm_gpio_alloc_generic_chip(dev, irq_base, 1);
#endif
	
	return 0;
	
 fail:	
	if (dev->irq >= 0){
		/* perform initialization to make sure IRQ is disabled */
		iic_dev_init(dev);
		free_irq(dev->irq, dev);
	}	

	iounmap(dev->vaddr);
 fail2: 
	release_mem_region((long)base, 0x40);
 fail1:
	return ret;
}

/*
 * Cleanup initialized IIC interface
 */
static void ix_ssm_exit_local(void)
{
	struct ix_ssm_private* dev = &mydev[0];
	volatile void __iomem *iic = dev->vaddr;

	BUG_ON(dev == NULL);
	printk(KERN_INFO "IX-SSM remove (%p)\n", dev);

#ifdef IXSSM_MCU_GPIO
	DBG("%d: iounmap %d\n", dev->idx, dev->ichip_irq_base);
	irq_free_descs(dev->ichip_irq_base, 1);

	DBG("%d: gpiochip_remove %p\n", dev->idx, &dev->gpio);
	gpiochip_remove(&dev->gpio);
#endif

	DBG("%d: i2c_del_adapter %p\n", dev->idx, &dev->adap);
	i2c_del_adapter(&dev->adap);
	if (dev->irq >= 0){
		/* disable all interrupts */
		dev->int_shadow &= ~(SSM_I2C_INT_IE+SSM_I2C_INT_MIE);
		writew(dev->int_shadow, iic+SSM_I2C_INT);

		//iic_interrupt_mode(dev, 0);	
		DBG("%d: free_irq %d,%p\n", dev->idx, dev->irq, dev);
		free_irq(dev->irq, dev);
	}

	DBG("%d: iounmap %p\n", dev->idx, dev->vaddr);
	iounmap(dev->vaddr);
	DBG("%d: release_mem_region 0x%x\n", dev->idx, base);
	release_mem_region((resource_size_t)(unsigned long)base, 0x40);

	DBG("%d: platform_device_unregister %p\n", dev->idx, ix_ssm_pdev);
	platform_device_unregister(ix_ssm_pdev);
}


#if 0
static struct platform_driver ix_ssm_driver = {
	.probe		= iic_probe,
	.remove		= iic_remove,
	.driver		= {
		.name	= "IX-SSM-I2C",
		.owner	= THIS_MODULE,
	},
};

static int __init iic_init(void)
{
	printk(KERN_INFO "IX-SSM I2C driver v" DRIVER_VERSION "\n");
	return platform_register_driver(&ix_ssm_driver);
}

static void __exit iic_exit(void)
{
	platform_unregister_driver(&ix_ssm_driver);
}
#endif

static void __exit ix_ssm_exit(void)
{
        ix_ssm_exit_local();
}

module_param(base, uint, 0);
module_param(irq, int, 0);

module_init(ix_ssm_init);
module_exit(ix_ssm_exit);

MODULE_DESCRIPTION("IX-SSM-I2C driver v" DRIVER_VERSION);
MODULE_AUTHOR("Stefan Althoefer");
MODULE_LICENSE("GPL");

