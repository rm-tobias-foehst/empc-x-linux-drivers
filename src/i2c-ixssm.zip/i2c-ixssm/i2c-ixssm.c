/*
 * drivers/i2c/busses/i2c-ix_ssm.c
 *
 * Support for the I2C interface on IX power module
 *
 * Copyright (c) 2013 Stefan Alth�fer (as@janztec.com)
 *
 * Based on original work by some driver in linux/driver/i2c.
 *
 * This program is free software; you can redistribute  it and/or modify it
 * under  the terms of  the GNU General  Public License as published by the
 * Free Software Foundation;  either version 2 of the  License, or (at your
 * option) any later version.
 *
 */

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/ioport.h>
#include <linux/delay.h>
#include <linux/slab.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <asm/irq.h>
#include <asm/io.h>
#include <linux/platform_device.h>
#include <linux/i2c.h>


#define SSM_I2C_DATA    0x00
#define SSM_I2C_CNTRL   0x04
#define SSM_I2C_INT     0x08
#define SSM_SPI_DATA    0x0C
#define SSM_SPI_CNTRL   0x10
#define SSM_SPI_INT     0x14
#define SSM_BITRATE     0x18
#define SSM_RESET       0x1c

/* I2C_DATA */
#define SSM_I2C_DATA_ACKI   (1<<0)  /* on reads */
#define SSM_I2C_DATA_BUSY   (1<<1)  /* on reads */
#define SSM_I2C_DATA_AUXINT (1<<2)  /* on reads */
#define SSM_I2C_DATA_INT    (1<<3)  /* on reads */
#define SSM_I2C_DATA_IN(X)  (((X)>>8)&0xff)
#define SSM_I2C_DATA_OUT(X) (((X)&0xff)<<8)
#define SSM_I2C_DATA_S      (1<<2)  /* write only */
#define SSM_I2C_DATA_P      (1<<3)  /* write only */

/* I2C_CNTRL */
#define SSM_I2C_CNTRL_ACKO  (1<<0)  /* write only */
#define SSM_I2C_CNTRL_RW    (1<<1)  /* write only */
#define SSM_I2C_CNTRL_S     (1<<2)  /* write only */
#define SSM_I2C_CNTRL_P     (1<<3)  /* write only */

/* I2C_INT */
#define SSM_I2C_INT_IE      (1<<0)  /* write only */
#define SSM_I2C_INT_AUXIE   (1<<1)  /* write only */
#define SSM_I2C_INT_ACK     (1<<2)  /* write only */


#define DRIVER_VERSION "1.1"


static uint base;
static int irq;


#define DBG_LEVEL 0

#ifdef DBG
#undef DBG
#endif

#ifdef DBG2
#undef DBG2
#endif

#if DBG_LEVEL > 0
#  define DBG(f,x...)   printk(KERN_DEBUG "ix-ssm-i2c" f, ##x)
#else
#  define DBG(f,x...)   ((void)0)
#endif
#if DBG_LEVEL > 1
#  define DBG2(f,x...)  DBG(f, ##x)
#else
#  define DBG2(f,x...)  ((void)0)
#endif
#if DBG_LEVEL > 2
static void dump_iic_regs(const char* header, struct ix_ssm_private* dev)
{
	volatile void __iomem *iic = dev->vaddr;
}
#  define DUMP_REGS(h,dev)	dump_iic_regs((h),(dev))
#else
#  define DUMP_REGS(h,dev)	((void)0)
#endif

static void ix_ssm_exit_local(void);

struct ix_ssm_private {
	struct i2c_adapter	 adap;
	int			 idx;
	int			 irq;
	int			 busy_timeout;
	unsigned short		 cntrl_shadow;
	unsigned short		 int_shadow;
	unsigned short		 bitrate_shadow;
	volatile int		 int_enable;
	volatile void __iomem	 *vaddr;
	wait_queue_head_t	 wq;
	volatile int             intflg;
};

static struct ix_ssm_private mydev[1];


/*
 * Initialize IIC interface.
 */
static void iic_dev_init(struct ix_ssm_private* dev)
{
	volatile void __iomem *iic = dev->vaddr;

	/* Perform reset */
	writew(0, iic+SSM_RESET);

	dev->int_shadow = 0;
	writew(dev->int_shadow, iic+SSM_I2C_INT);

	/* Set 400kHz bitrate */
	dev->bitrate_shadow = 1;
	writew(dev->bitrate_shadow, iic+SSM_BITRATE);

	dev->cntrl_shadow = 0;

	DUMP_REGS("iic_init", dev);
}

/* 
 * Reset IIC interface
 */
static void iic_dev_reset(struct ix_ssm_private* dev)
{
	/*volatile void __iomem *iic = dev->vaddr;*/

	/* FIXME: try to resolve stuck devices */
	
	/* Reinitialize interface */
	iic_dev_init(dev);
}


/*
 * IIC interrupt handler
 */
static irqreturn_t iic_handler(int irq, void *dev_id)
{
	struct ix_ssm_private* dev = (struct ix_ssm_private*)dev_id;
	volatile void __iomem *iic = dev->vaddr;
	unsigned short dreg;

	if( dev->irq >= 0 ){
		dreg = readw(iic+SSM_I2C_DATA);
		if( dreg & SSM_I2C_DATA_INT ){
			/* Ack IRQ */
		        writew(dev->int_shadow+SSM_I2C_INT_ACK, iic+SSM_I2C_INT);
			
			dev->intflg = 1;
			wake_up(&dev->wq);
			return IRQ_HANDLED;
		}
	}

	return IRQ_NONE;
}


/*
 * Check for I2C unit to be idle. If not idle, then less than
 * zero is returned, else the value of the data register.
 */
static int iic_check_for_idle(struct ix_ssm_private* dev)
{
	volatile void __iomem *iic = dev->vaddr;
	unsigned short	dreg;
	
	dreg = readw(iic+SSM_I2C_DATA);
	if( (dreg & SSM_I2C_DATA_BUSY) ){
		return -1;
	} else {
		return dreg & 0xffff;
	}
}

/*
 * Wait for I2C unit to become idle. On timeout, return less than
 * zero, else the value of the data register.
 */
static int iic_wait_for_idle(struct ix_ssm_private* dev, int force_poll)
{
	volatile void __iomem *iic = dev->vaddr;
	unsigned short	dreg;
	int  timeout;
	int  ret;

	if( (dev->irq >= 0) && !force_poll ){
		ret = wait_event_timeout(
		        dev->wq, dev->intflg,
			dev->busy_timeout);
		
		if( (ret > 0) || (ret==0 && dev->intflg==1) ){
			dreg = readw(iic+SSM_I2C_DATA);
			return dreg & 0xffff;
		} else {
			/* Timeout or signal. */
			return -1;
		}
	} else {
		timeout = 1000;
		while(1){
			timeout--;
			dreg = readw(iic+SSM_I2C_DATA);
			if( (dreg & SSM_I2C_DATA_BUSY) ){
				if( timeout > 0 ){
					continue;
				} else {
					return -1;
				}
			} else {
				return dreg & 0xffff;
			}
		}
	}
}
	
/* build the addr byte to transmitt from address and flags */
static int make_address_byte(struct i2c_msg* pm)
{
	int    rw;

	if( unlikely(pm->flags&I2C_M_REV_DIR_ADDR) ){
		rw = (pm->flags&I2C_M_RD)?0:1;
	} else {
		rw = (pm->flags&I2C_M_RD)?1:0;
	}
	return (pm->addr<<1)+rw;
}


/*
 * Low level master transfer routine
 *
 * FIXME: Need to handle I2C_M_NOSTART and I2C_M_NO_RD_ACK
 *
 */
static int iic_xfer_bytes(struct ix_ssm_private* dev, struct i2c_msg* pm, 
			  int combined_xfer)
{
	volatile void __iomem *iic = dev->vaddr;
	int		      i, ret = 0;
	int		      dreg;
	int		      stopped = 0;

	DBG2("%d: xfer_bytes (addr=0x%.2x, flags=0x%x, len=%d)\n", dev->idx,
	     pm->addr, pm->flags, pm->len );

	if( iic_check_for_idle(dev) < 0 ){
		DBG("%d: Unit not idle (call iic_dev_reset)\n", dev->idx);
		iic_dev_reset(dev);
	}

	/* trigger start condition and transfer address byte */
	dev->intflg = 0;
	dev->cntrl_shadow &= ~SSM_I2C_CNTRL_RW;
	writew(dev->cntrl_shadow, iic+SSM_I2C_CNTRL);

	dreg = SSM_I2C_DATA_S + SSM_I2C_DATA_OUT(make_address_byte(pm));
	if( (pm->len == 0) && !combined_xfer ){
	    /* Shedule stop after address if not combined transfer */
	    dreg |= SSM_I2C_DATA_P;
	    stopped = 1;
	}
	DBG2("%d: write address %x, dr %x\n", dev->idx, dreg>>8, dreg & 0xff);
	writew(dreg, iic+SSM_I2C_DATA);

	/* wait for start complete and address byte to transfer */
	if( (dreg=iic_wait_for_idle(dev,0)) < 0 ){
		DBG("%d: Not idle after start/address\n", dev->idx);
		ret = -EFAULT;
	} else {
		if( (dreg & SSM_I2C_DATA_ACKI) & !(pm->flags & I2C_M_IGNORE_NAK) ){
			DBG2("%d: No acknowledge from peer (addr)\n", dev->idx);
			ret = -EREMOTEIO;
		}
	}

	/* transfer data (will do nothing if len=0) */
	if( pm->flags & I2C_M_RD ){
		/* Read */
		dev->cntrl_shadow |=  SSM_I2C_CNTRL_RW;
		if( pm->len > 1 ){
			dev->cntrl_shadow &= ~SSM_I2C_CNTRL_ACKO;
		} else {
			dev->cntrl_shadow |=  SSM_I2C_CNTRL_ACKO;
		}
		writew(dev->cntrl_shadow, iic+SSM_I2C_CNTRL);
		for(i=0; (i<pm->len) && (ret==0); i++){
			dev->intflg = 0;

			if( ((i+1) >= pm->len) & (i!=0) ){
				/* No ACK for last byte */
				dev->cntrl_shadow |=  SSM_I2C_CNTRL_ACKO;
				writew(dev->cntrl_shadow, iic+SSM_I2C_CNTRL);
			}

			dreg = 0;
			if( ((i+1)==pm->len) && !combined_xfer ){
			    /* Shedule stop after last byte if not combined transfer */
			    dreg |= SSM_I2C_DATA_P;
			    stopped = 1;
			}
			DBG2("%d: byte in, dr %x\n", dev->idx, dreg & 0xff);
			writew(dreg, iic+SSM_I2C_DATA); /* dummy write triggers read */

			/* wait for data transfer (and maybe stop) to finish */
			if( (dreg=iic_wait_for_idle(dev,0)) < 0 ){
				DBG("%d: Not idle after read\n", dev->idx);
				ret = -EFAULT;
			}

			pm->buf[i] = SSM_I2C_DATA_IN(dreg);
		}
	} else {
		/* Write */
		dev->cntrl_shadow &= ~SSM_I2C_CNTRL_RW;
		writew(dev->cntrl_shadow, iic+SSM_I2C_CNTRL);
		for(i=0; (i<pm->len) && (ret==0); i++){
			dev->intflg = 0;

			dreg = SSM_I2C_DATA_OUT(pm->buf[i]);
			if( ((i+1)==pm->len) && !combined_xfer ){
			    /* Shedule stop after last byte if not combined transfer */
			    dreg |= SSM_I2C_DATA_P;
			    stopped = 1;
			}
			DBG2("%d: byte out %x, dr %x\n", dev->idx, dreg>>8, dreg & 0xff);
			writew(dreg, iic+SSM_I2C_DATA);

		
			/* wait for data transfer (and maybe stop) to finish */
			if( (dreg=iic_wait_for_idle(dev,0)) < 0 ){
				DBG("%d: Not idle after write\n", dev->idx);
				ret = -EFAULT;
			}
			if( (dreg & SSM_I2C_DATA_ACKI) & !(pm->flags & I2C_M_IGNORE_NAK) ){
				DBG("%d: No acknowledge from peer (data)\n", dev->idx);
				ret = -EREMOTEIO;
			}
		}
	}

	if( ret && !stopped ){
		/* Force  a stop condition when there had been an error and
		   stop had not already been sheduled. */
		writew(dev->cntrl_shadow | SSM_I2C_CNTRL_P, iic+SSM_I2C_CNTRL);
	    
		if( (dreg=iic_wait_for_idle(dev,0)) < 0 ){
			DBG("%d: Not idle after stop\n", dev->idx);
			ret = -EFAULT;
		}
	}
	
	return ret > 0 ? 0 : ret;
}

/*
 * Generic master transfer entrypoint. 
 * Returns the number of processed messages or error (<0)
 */
static int iic_xfer(struct i2c_adapter *adap, struct i2c_msg *msgs, int num)
{
	struct ix_ssm_private* dev = (struct ix_ssm_private*)(i2c_get_adapdata(adap));
	int    i, ret = 0;
	
	DBG2("%d: iic_xfer, %d msg(s)\n", dev->idx, num);
	
	if (!num)
		return 0;
	
	/* Do real transfer */
	for (i = 0; i < num && !ret; ++i)
		ret = iic_xfer_bytes(dev, &msgs[i], i < num - 1);

	return ret < 0 ? ret : num;
}


static u32 iic_func(struct i2c_adapter *adap)
{
	return I2C_FUNC_I2C | I2C_FUNC_SMBUS_EMUL;
}

static const struct i2c_algorithm iic_algo = {
	.master_xfer	= iic_xfer,
	.functionality	= iic_func
};


/*
 * Register single IIC interface
 */
static int __init ix_ssm_init(void){
	struct ix_ssm_private* dev = &mydev[0];
	struct i2c_adapter* adap;
	volatile void __iomem *iic;
	int ret;
	
	dev->idx = 0;

#if 1
	if (!request_mem_region((resource_size_t)((unsigned long)base), 0x40, "ix_ssm")) {
		ret = -EBUSY;
		goto fail1;
	}
#endif

        if (!(dev->vaddr = ioremap((resource_size_t)((unsigned long)base), 0x40))) {
		printk(KERN_CRIT "ix-ssm-iic%d: failed to ioremap device registers\n",
		       dev->idx);
		ret = -ENXIO;
		goto fail2;
	}
	DBG("%d: vaddr=%p\n", dev->idx, dev->vaddr);
	iic = dev->vaddr;

	printk(KERN_INFO "IX-SSM init @ %x (irq = %d)\n", base, irq);
	init_waitqueue_head(&dev->wq);

	/* Initialize IIC interface (to make sure IRQ is disabled) */
	iic_dev_init(dev);
	
	dev->irq = irq;
	if (dev->irq >= 0){
		/* Disable interrupts until we finish initialization,
		   assumes level-sensitive IRQ setup...
		*/
		//iic_interrupt_mode(dev, 0);
		if (request_irq(dev->irq, iic_handler,
				IRQF_SHARED, "IX-SSM-I2C", dev)){
			printk(KERN_ERR "ix-ssm-i2c%d: request_irq %d failed\n", 
			       dev->idx, dev->irq);
			/* Fallback to the polling mode */	
			dev->irq = -1;
		} else {
		    /* enable the interrupt */
		    dev->int_shadow |= SSM_I2C_INT_IE;
		    writew(dev->int_shadow, iic+SSM_I2C_INT);
		}
	}
	
	if (dev->irq < 0)
		printk(KERN_WARNING "ix-ssm-i2c%d: using polling mode\n", 
		       dev->idx);
		
	dev->busy_timeout = msecs_to_jiffies(13) + 1; /* 1sec */
	
	/* Register it with i2c layer */
	adap = &dev->adap;
	strcpy(adap->name, "IX-SSM-I2C");
	i2c_set_adapdata(adap, dev);
	//adap->id = 0x9999;
	adap->class = I2C_CLASS_HWMON;
	adap->algo = &iic_algo;
	adap->timeout = 1;
	adap->retries = 1;
	adap->dev.parent = &platform_bus; /* fix a warning */

	if ((ret = i2c_add_adapter(adap)) != 0){
		printk(KERN_CRIT "ix-ssm-i2c%d: failed to register i2c adapter\n",
		       dev->idx);
		goto fail;
	}
	
	return 0;

 fail:	
	if (dev->irq >= 0){
		/* perform initialization to make sure IRQ is disabled */
		iic_dev_init(dev);
		free_irq(dev->irq, dev);
	}	

	iounmap(dev->vaddr);
 fail2: 
	release_mem_region((long)base, 0x40);
 fail1:
	return ret;
}

/*
 * Cleanup initialized IIC interface
 */
static void ix_ssm_exit_local(void)
{
	struct ix_ssm_private* dev = &mydev[0];
	volatile void __iomem *iic = dev->vaddr;

	BUG_ON(dev == NULL);
	printk(KERN_INFO "IX-SSM remove (%p)\n", dev);
	i2c_del_adapter(&dev->adap);
	if (dev->irq >= 0){
	    /* disable the interrupt */
	    dev->int_shadow &= ~SSM_I2C_INT_IE;
	    writew(dev->int_shadow, iic+SSM_I2C_INT);

	    //iic_interrupt_mode(dev, 0);	
	    free_irq(dev->irq, dev);
	}
	iounmap(dev->vaddr);
	release_mem_region((long)base, 0x40);
}


#if 0
static struct platform_driver ix_ssm_driver = {
	.probe		= iic_probe,
	.remove		= iic_remove,
	.driver		= {
		.name	= "IX-SSM-I2C",
		.owner	= THIS_MODULE,
	},
};

static int __init iic_init(void)
{
	printk(KERN_INFO "IX-SSM I2C driver v" DRIVER_VERSION "\n");
	return platform_register_driver(&ix_ssm_driver);
}

static void __exit iic_exit(void)
{
	platform_unregister_driver(&ix_ssm_driver);
}
#endif

static void __exit ix_ssm_exit(void)
{
        ix_ssm_exit_local();
}

module_param(base, uint, 0);
module_param(irq, int, 0);

module_init(ix_ssm_init);
module_exit(ix_ssm_exit);

MODULE_DESCRIPTION("IX-SSM-I2C driver v" DRIVER_VERSION);
MODULE_AUTHOR("Stefan Althoefer");
MODULE_LICENSE("GPL");

