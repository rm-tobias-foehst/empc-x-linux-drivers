/* Test MCU INT (waiting for GPIO change)*/

/* A more robust version with detecting the GPIO number is
   t_mcuint.pl */

#include <stdio.h>
#include <sys/select.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <poll.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

#define MAX_BUF 64

char *gpiofile = "/sys/class/gpio/gpio511/value";

int main(void)
{
    fd_set exceptfds;
    struct pollfd fdset[2];
    int gpio_fd, rc;
    char buf[MAX_BUF];
    int len;

    gpio_fd = open(gpiofile, O_RDONLY | O_NONBLOCK);
    printf("gpio_fd:%d\n", gpio_fd);
    if( gpio_fd < 0 ){
	return -1;
    }

    len = read(gpio_fd, buf, MAX_BUF);
    buf[len] = '\0';
    printf("gpio state: %s", buf);

#if 1
    FD_ZERO(&exceptfds);
    FD_SET(gpio_fd, &exceptfds);

    printf("Waiting with select ...\n");
    rc = select(gpio_fd+1, 
		NULL,               // readfds - not needed
		NULL,               // writefds - not needed
		&exceptfds,
		NULL);              // timeout (never)
    printf("select()=%d\n", rc);

    if (rc > 0 && FD_ISSET(gpio_fd, &exceptfds))
    {
	lseek(gpio_fd, 0, SEEK_SET);
	len = read(gpio_fd, buf, MAX_BUF);
	buf[len] = '\0';
	printf("gpio state: %s", buf);
    }
#else

    memset((void*)fdset, 0, sizeof(fdset));
    fdset[0].fd = gpio_fd;
    fdset[0].events = POLLPRI;

    printf("Waiting with poll ...\n");
    rc = poll(fdset, 1, -1);      
    printf("poll()=%d\n", rc);

    if (rc < 0) {
	printf("\npoll() failed!\n");
	return -1;
    }
      
    if (fdset[0].revents & POLLPRI) {
	lseek(gpio_fd, 0, SEEK_SET);
	len = read(gpio_fd, buf, MAX_BUF);
	buf[len] = '\0';
	printf("gpio state: %s", buf);
    }
#endif
	
    return 0;
}
