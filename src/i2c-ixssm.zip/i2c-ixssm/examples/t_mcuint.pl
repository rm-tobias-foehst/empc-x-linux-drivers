#!/usr/bin/perl

# Test IX-SSM mcu interrupt

use strict;
use Fcntl ":seek";

# read complete file into a scalar
sub slurp_file {
    my $filename = $_[0];
    my $in;

    open(my $fh, "<", $filename)  or  return undef;
    { local $/ = undef;   # we want whole file
      $in = <$fh>;
    }
    close $fh;
    return $in;
}
# read file and chomp (e.g. for /sys files)
sub slurp_attr {
    my $in = slurp_file($_[0]);
    chomp $in;
    return $in;
}
sub write_attr {
    my $filename = $_[0];
    open(my $fh, ">", $filename)  or  return 0;
    print $fh $_[1];
    return 1;
}
# Return list with all entries in a dir, without . and ..
sub slurp_dir {
    my $dirname = $_[0];

    opendir(my $d, $dirname);
    my @ent = readdir($d);
    closedir($d);

    my @files = grep( $_ !~ /^..?$/ , @ent);
    return @files;
}

# Search for our GPIO chip
my $ixssm_gpiochip;
my $ixssm_gpio_no;
my $ixssm_gpio;
for my $chip (slurp_dir("/sys/class/gpio")) {
    if( $chip !~ /^gpiochip/ ){
	next;
    }
    my $label = slurp_attr("/sys/class/gpio/$chip/label");
    if( $label eq "IX-SSM-GPIO" ){
	$ixssm_gpiochip = $chip;
    }
}

if( ! defined($ixssm_gpiochip) ){
    die "IX-SSM-GPIO not found";
}
  
$ixssm_gpio_no = slurp_attr("/sys/class/gpio/$ixssm_gpiochip/base");
$ixssm_gpio = "/sys/class/gpio/gpio$ixssm_gpio_no";

if( ! -r $ixssm_gpio ){
    # need to export to userspace
    print "export\n";
    write_attr("/sys/class/gpio/export", $ixssm_gpio_no);

    if( ! -r $ixssm_gpio ){
	die "can not export GPIO $ixssm_gpio";
    }
}
    
my $mcuint = slurp_attr("$ixssm_gpio/value");
print "MCUINT (gpio$ixssm_gpio_no) : $mcuint\n";

write_attr("$ixssm_gpio/edge", "none");
write_attr("$ixssm_gpio/edge", "falling");

my $timeout = 15;
my $timeleft;
my $nfound;
my $eout;
my $ein = '';

open(my $gpiofh, "<", "$ixssm_gpio/value")  or  "die can not open gpio";
# Hmm: this is not in the linux documentation. You must read ./value
# before you can do the select() or poll(). This is not a perl gotcha,
# it also appears with a C demo program.
$mcuint = <$gpiofh>;
if( $mcuint == 0 ){
    print "MCUINT already low, exiting\n";
    exit 0;
}
vec($ein,fileno($gpiofh),1) = 1;
($nfound,$timeleft) =
    select(undef, undef, $eout=$ein, $timeout);

if( $nfound == 0 ){
    print "MCUINT timeout\n";
} elsif( $nfound == 1 and vec($eout,fileno($gpiofh),1) ){
    print "MCUINT interrupt\n";
    seek($gpiofh, 0, SEEK_SET) or die "can not seek";
    $mcuint = <$gpiofh>;
    print "MCUINT : $mcuint\n";
}

