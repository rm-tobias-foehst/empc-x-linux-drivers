/* -*-C-*-
 * debug.h - debug defines to debug the driver
 *
 *-----------------------------------------------------------------------
 *
 *                Copyright (c) 2016 JANZ Tec AG
 *                        All Rights Reserved
 *
 * Permission is hereby granted to licensees of JANZ Tec AG
 * products to use or abstract this computer program for the sole
 * purpose of implementing a product based on JANZ Tec AG
 * products.   No other rights to reproduce, use, or disseminate
 * this computer program, whether in part or in whole, are granted.
 *
 * JANZ Tec AG makes no representation or warranties with respect
 * to the performance of this computer program, and specifically
 * disclaims any responsibility for any damages, special or consequential,
 * connected with the use of this program.
 *
 * JANZ Tec AG products are not authorized for use as critical
 * components in life support devices or systems without the express
 * written approval of JANZ Tec AG.
 *
 *-----------------------------------------------------------------------
 *
 * $Id: debug.h,v 1.4 2003/03/25 08:20:39 stefan Exp lxdriver $
 *
 *-----------------------------------------------------------------------
 */

/*
 * $Log: debug.h,v $
 * Revision 1.4  2003/03/25 08:20:39  stefan
 * *** empty log message ***
 *
 * Revision 1.3  1998/06/16 11:23:36  root
 * Make it ANSI conform
 *
 * Revision 1.2  1998/06/15 12:56:01  root
 * Modified debug flags
 *
 * Revision 1.1  1997/05/16 07:30:41  root
 * Initial revision
 *
 */


/************************************************************************/
/* DEBUG-tool								*/
/************************************************************************/

#ifndef debug_DEFINED
#define debug_DEFINED
#ifdef __cplusplus
extern "C" {
#endif

#if DEBUG
#define	LOG_INIT	(1 <<  0)
#define	LOG_OPEN	(1 <<  1)
#define	LOG_CLOSE	(1 <<  2)
#define	LOG_INTR	(1 <<  3)
#define	LOG_READ	(1 <<  4)
#define	LOG_WRITE	(1 <<  5)
#define	LOG_IOCTL	(1 <<  6)
#define	LOG_DEF		(1 <<  7)

#define	LOG_WATCH	(1 <<  8)
#define	LOG_MIN		(1 <<  9)
#define	LOG_AST		(1 << 10)
#define	LOG_FUNC	(1 << 11)
#define	LOG_EXIT	(1 << 12)
#define	LOG_INT		(1 << 13)
#define	LOG_MMAP	(1 << 14)
#define	LOG_LOCK	(1 << 15)
#define	LOG_RESET	(1 << 16)
#define	LOG_SEM		(1 << 17)
#define	LOG_RMAIL	(1 << 18)
#define	LOG_WRFAST	(1 << 19)
#define	LOG_RDFAST	(1 << 20)
#define	LOG_POOL	(1 << 21)

#define	LOG_MAX		(1 << 31)

#if 0
static int      debug = LOG_RESET | LOG_INIT | LOG_OPEN | LOG_CLOSE | \
			LOG_IOCTL | LOG_INTR | LOG_WRITE | LOG_READ | LOG_MAX;
#else
static int      debug =   LOG_INIT| LOG_OPEN | LOG_IOCTL;
#endif
int printf_ (char *fmt, ...);

/* #define	LOG(level, message) if(debug & level) logMsg message */
#define	LOG(level, message) if(debug & level) printk message
#else
#define	LOG(level, message)
#endif

#ifdef __cplusplus
}
#endif
#endif /* debug_DEFINED */

