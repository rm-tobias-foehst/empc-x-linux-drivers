/*
 * Copyright (C) 2012-2019 Janz Tec AG
 * Parts of this software are based on (derived) the following:
 *
 * - Socketcan SJA1000 drivers
 *   Copyright (C) 2007 Wolfgang Grandegger <wg@grandegger.com>
 *   Copyright (c) 2002-2007 Volkswagen Group Electronic Research
 *   Copyright (c) 2003 Matthias Brukner, Trajet Gmbh, Rebenring 33,
 *   38106 Braunschweig, GERMANY
 *   Copyright (C) 2008 David Müller, <d.mueller@elsoft.ch>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the version 2 of the GNU General Public License
 * as published by the Free Software Foundation
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <linux/version.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/interrupt.h>
#include <linux/netdevice.h>
#include <linux/delay.h>
#include <linux/pci.h>
#include <linux/platform_device.h>
#include <linux/can.h>
#include <linux/can/dev.h>
#include <linux/io.h>

#include "sja1000.h"
#include "jtec_can_version.h"

#define DRV_NAME  "jtec_can"

#define MAX_DEVICES             16      /* max # of devices supported   */

/*

   insmod jtec_can.o io=unused,<MEM-BASE>,<IRQ-NUM>(,more devices, ...)
                          |       |           |
                          |       |           used irq
                          |       base address
                          unused, but must set. e.g. with 0
*/

struct io_type {
        unsigned long   iobase;
        int             interrupt;
};

struct io {
        long            unused;
        struct io_type  io[MAX_DEVICES];
};

struct jtec_can_card {
        int 			channels;
        struct net_device 	*net_dev[MAX_DEVICES];
        void __iomem 		*base_addr[MAX_DEVICES]; /* virtual address */
	int 			irq[MAX_DEVICES];
};

static unsigned int   io[33] = { -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
                                 -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1 };
static struct platform_device	*pc_pdev;

MODULE_AUTHOR("Gerd Schliebusch - Janz Tec AG");
MODULE_DESCRIPTION("Socket-CAN driver for Janz Tec emPC-x1600");
#if LINUX_VERSION_CODE < KERNEL_VERSION(5,12,0)
MODULE_SUPPORTED_DEVICE("Janz Tec AG emPC-x1600 CAN");
#endif
MODULE_LICENSE("GPL v2");
MODULE_PARM_DESC(io, "IO Spec: io=<unused e.g. 0>,<iobase>,<irq> (,next modules, ....)");

module_param_array(io, uint, NULL, 0644);


#define JTEC_CAN_CAN_CLOCK (16000000 / 2)

/*
 * The board configuration is probably following:
 * RX1 is connected to ground.
 * TX1 is not connected.
 * CLKO is not connected.
 * Setting the OCR register to 0xDA is a good idea.
 * This means normal output mode, push-pull and the correct polarity.
 */
#define JTEC_CAN_OCR         (OCR_TX0_PUSHPULL | OCR_TX1_PUSHPULL)

/*
 * In the CDR register, you should set CBP to 1.
 * You will probably also want to set the clock divider value to 7
 * (meaning direct oscillator output) because the second SJA1000 chip
 * is driven by the first one CLKOUT output.
 */
#define JTEC_CAN_CDR             (CDR_CBP | CDR_CLKOUT_MASK)

static u8 jtec_can_read_reg(const struct sja1000_priv *priv, int port)
{
        return readb(priv->reg_base + port);
}

static void jtec_can_write_reg(const struct sja1000_priv *priv,
                                 int port, u8 val)
{
        writeb(val, priv->reg_base + port);
}


static ssize_t termination_show(struct device *dev,
				struct device_attribute *attr, char *buf)
{
	struct net_device *netdev = to_net_dev(dev);
	struct sja1000_priv *priv = netdev_priv(netdev);
    
	return sprintf(buf, "Usage to enable or disable CAN termination resistor (disabled by default):\n Enable:\n  $ echo 1 > /sys/class/net/canX/termination\n Disable:\n  $ echo 0 > /sys/class/net/canX/termination\n \n");
}

static ssize_t termination_store(struct device *dev,
				 struct device_attribute *attr,
				 const char *buf, size_t count)
{
	struct net_device *netdev = to_net_dev(dev);
	struct sja1000_priv *priv = netdev_priv(netdev);
	int term = 0;
	
	if (kstrtoint(buf, 10, &term)==0) {
		jtec_can_write_reg( priv, 0x100, (term==1)?1:0 );
	}

	return count;
}

static struct device_attribute termination_attr = {
	.attr = {
		.name = "termination",
		.mode = 0666 },
	.show	= termination_show,
	.store	= termination_store
};

/*
 * Check if a CAN controller is present at the specified location
 * by trying to set 'em into the PeliCAN mode
 */
static inline int jtec_can_check_chan(const struct sja1000_priv *priv)
{
	unsigned char res;

	/* Make sure SJA1000 is in reset mode */
	priv->write_reg(priv, SJA1000_MOD, 1);
	priv->write_reg(priv, SJA1000_CDR, CDR_PELICAN);
	/* read reset-values */
	res = priv->read_reg(priv, SJA1000_CDR);
	if (res == CDR_PELICAN)
		return 1;
	return 0;
}

static int jtec_can_del_card(struct platform_device *pdev)
{
	struct jtec_can_card *card = platform_get_drvdata(pdev);
	struct net_device *dev;
	int i;

	if(card) {
		for (i = 0; i < MAX_DEVICES; i++) {
			if(io[1+2*i] == -1) {
				continue;
			}

			dev = card->net_dev[i];
			if (!dev) {
				continue;
			}
      
			device_remove_file(&dev->dev, &termination_attr);
      
			unregister_sja1000dev(dev);
			free_sja1000dev(dev);
			if (card->base_addr[i] != NULL) {
				iounmap(card->base_addr[i]);
			}
		}
		kfree(card);
	}
	return(0);
}

/*
 * Probe PCI device for EMS CAN signature and register each available
 * CAN channel to SJA1000 Socket-CAN subsystem.
 */
//static int __init jtec_can_add_card(struct platform_device *pdev)
static int jtec_can_add_card(struct platform_device *pdev)
{
	struct sja1000_priv *priv;
	struct net_device *dev;
	struct jtec_can_card *card;
	int err, i;
  int rc1;
        unsigned long		baddr;         /* modul address        */  
        unsigned char   *vaddr;        /* modul address        */  
        unsigned int    irq;

	/* Allocating card structures to hold addresses, ... */
	card = kzalloc(sizeof(struct jtec_can_card), GFP_KERNEL);
	if (card == NULL) {
		err = -ENOMEM;
		goto failure_cleanup;
	}

	platform_set_drvdata(pdev, card);

        /*
         * Check for the old io=<...> parameter
         */
	/* Detect available channels */
	for (i = 0; i < MAX_DEVICES; i++) {
		if(io[1+2*i] == -1) {
			continue;
		}

		baddr = (unsigned long) io[1+2*i];
		vaddr = (unsigned char *) ioremap(baddr, 4096);
		irq   = io[2+2*i];

printk(KERN_INFO "jtec_can(%d): io=0x%lx (0x%lx), irq=%d\n", i, (unsigned long)baddr, (unsigned long)vaddr, irq);

		dev = alloc_sja1000dev(0);
		if (dev == NULL) {
			err = -ENOMEM;
			goto failure_cleanup;
		}

		card->net_dev[i] = dev;
		card->base_addr[i] = vaddr;
		card->irq[i] = irq;

		priv = netdev_priv(dev);
		priv->priv = card;
		priv->irq_flags = IRQF_SHARED;
		dev->irq = irq;
		priv->reg_base = vaddr;
		priv->read_reg  = jtec_can_read_reg;
		priv->write_reg = jtec_can_write_reg;

		/* Check if channel is present */
		if (jtec_can_check_chan(priv)) {
			priv->can.clock.freq = JTEC_CAN_CAN_CLOCK;
			priv->ocr = JTEC_CAN_OCR;
			priv->cdr = JTEC_CAN_CDR;

			SET_NETDEV_DEV(dev, &pdev->dev);

			/* Register SJA1000 device */
			err = register_sja1000dev(dev);
			if (err) {
				dev_err(&pdev->dev, "Registering device failed "
							"(err=%d)\n", err);
				free_sja1000dev(dev);
				goto failure_cleanup;
			}
      
      // create /sys/class/net/canX/termination sysfs entry
			rc1=device_create_file(&dev->dev, &termination_attr);
			if (rc1) {
			  printk(KERN_INFO "Register of termination sysfs entry failed!! (%d) \n", rc1 );
			}

			card->channels++;
		} else {
			free_sja1000dev(dev);
		}
	}
	if(!card->channels) {
		/* No device found */
		err = -ENODEV;
		goto failure_cleanup;
	}

	return 0;

failure_cleanup:
	dev_err(&pdev->dev, "Error: %d. Cleaning Up.\n", err);

	jtec_can_del_card(pdev);

	return err;
}


static struct platform_driver jtec_can_driver = {
        .probe = jtec_can_add_card,
        .remove = jtec_can_del_card,
        .driver = {
                .name = DRV_NAME,
                .owner = THIS_MODULE,
        },
};

static int __init jtec_can_init(void)
{
	struct resource r[2];
	int rc;

	printk(KERN_INFO "Register %s CAN netdevice driver $Revision: %d.%d $ %s\n",
		DRV_NAME, VERS_MAJOR, VERS_MINOR, ISO_TIME);

	/* fill in resources */
	memset(&r, 0, sizeof(r));

	pc_pdev = platform_device_register_simple(DRV_NAME, 0, r, ARRAY_SIZE(r));
	if (IS_ERR(pc_pdev))
	return PTR_ERR(pc_pdev);
	rc = platform_driver_probe(&jtec_can_driver, jtec_can_add_card);
	if(rc) {
		platform_device_unregister(pc_pdev);
		printk(KERN_ERR DRV_NAME " platform_driver_probe() failed (%d)\n", rc);
	}
  
  
  
	return rc;
}

static void __exit jtec_can_exit(void)
{
	printk(KERN_INFO "Unregister %s CAN netdevice driver\n", DRV_NAME);
	platform_driver_unregister(&jtec_can_driver);
	platform_device_unregister(pc_pdev);
}

module_init(jtec_can_init);
module_exit(jtec_can_exit);

